package com.example.wordle_15july2022;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.example.wordle_15july2022.R;
import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {

    Button play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        play = findViewById(R.id.play_btn);

        //button click activity
        play.setOnClickListener(v -> {
            Intent play = new Intent(Home.this, MainActivity.class);
            startActivity(play);
        });
    }

    //exit the app when back is pressed on home screen
    @Override
    public void onBackPressed(){
        super.onBackPressed();
        finishAffinity();
    }
}