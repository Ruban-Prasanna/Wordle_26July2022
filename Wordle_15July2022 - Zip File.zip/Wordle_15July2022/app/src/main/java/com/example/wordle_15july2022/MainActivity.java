package com.example.wordle_15july2022;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wordle_15july2022.R;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //TextView
    TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10,
            tv11, tv12, tv13, tv14, tv15, tv16, tv17, tv18, tv19,
            tv20, tv21, tv22, tv23, tv24, tv25, tv26, tv27, tv28, tv29, tv30;
    EditText iguess;
    Button btn;
    List<TextView> tvr1, tvr2, tvr3, tvr4, tvr5, tvr6;

    //Hashmap to store TextView of particular rows
    HashMap<Integer, List<TextView>> tv;

    //Hashmap to store character count and the row-wise characters guess count
    HashMap<Character, Integer> repeat, found;

    public static Integer rowCount, correctCount, pass_count;
    public static String word;
    Integer flag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //flag to set the winning status of player
        flag =0;

        //Arrays to store 5 letter words
        String[] strs = new String[] {"s1","s2","s3","s4","s5","s6","s7","s8","s9","s10",
                "s11","s12","s13","s14","s15","s16","s17","s18","s19","s20",
                "s21","s22","s23","s24","s25","s26","s27","s28","s29","s30",
                "s31","s32","s33","s34","s35","s36","s37","s38","s39","s40",
                "s41","s42","s43","s44","s45","s46","s47","s48","s49","s50"};

        //Getting a random word and setting it
        int randomIndex = new Random().nextInt(50);
        int resId = getResources().getIdentifier(strs[randomIndex ], "string", MainActivity.this.getPackageName());
        word = getString(resId);

        //word = "floor";
        word = word.toUpperCase(Locale.ROOT);
        repeat = new HashMap<>();
        found = new HashMap<>();

        //Storing character count of characters in the word
        for(int i=0;i<5;i++){
            if(repeat.containsKey(word.charAt(i))){
                repeat.put(word.charAt(i),repeat.get(word.charAt(i))+1);
            }else {
                repeat.put(word.charAt(i), 1);
            }

        }

        // Do not uncomment this part of the code or else
        // you have activated a cheat code!!!
        // Toast.makeText(getApplicationContext(), word, Toast.LENGTH_SHORT).show();

        //rowCount to keep track of guesses (rows)
        rowCount = 0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creating row-wise Collection of TextViews
        tvr1 = new ArrayList<>();
        tvr2 = new ArrayList<>();
        tvr3 = new ArrayList<>();
        tvr4 = new ArrayList<>();
        tvr5 = new ArrayList<>();
        tvr6 = new ArrayList<>();

        tv = new HashMap<>();

        btn = findViewById(R.id.btn_submit);
        iguess = findViewById(R.id.guess_input);

        tv1 = findViewById(R.id.textView1);
        tv2 = findViewById(R.id.textView2);
        tv3 = findViewById(R.id.textView3);
        tv4 = findViewById(R.id.textView4);
        tv5 = findViewById(R.id.textView5);
        tvr1.add(tv1);tvr1.add(tv2);tvr1.add(tv3);tvr1.add(tv4);tvr1.add(tv5);

        tv6 = findViewById(R.id.textView6);
        tv7 = findViewById(R.id.textView7);
        tv8 = findViewById(R.id.textView8);
        tv9 = findViewById(R.id.textView9);
        tv10 = findViewById(R.id.textView10);
        tvr2.add(tv6);tvr2.add(tv7);tvr2.add(tv8);tvr2.add(tv9);tvr2.add(tv10);

        tv11 = findViewById(R.id.textView11);
        tv12 = findViewById(R.id.textView12);
        tv13 = findViewById(R.id.textView13);
        tv14 = findViewById(R.id.textView14);
        tv15 = findViewById(R.id.textView15);
        tvr3.add(tv11);tvr3.add(tv12);tvr3.add(tv13);tvr3.add(tv14);tvr3.add(tv15);

        tv16 = findViewById(R.id.textView16);
        tv17 = findViewById(R.id.textView17);
        tv18 = findViewById(R.id.textView18);
        tv19 = findViewById(R.id.textView19);
        tv20 = findViewById(R.id.textView20);
        tvr4.add(tv16);tvr4.add(tv17);tvr4.add(tv18);tvr4.add(tv19);tvr4.add(tv20);

        tv21 = findViewById(R.id.textView21);
        tv22 = findViewById(R.id.textView22);
        tv23 = findViewById(R.id.textView23);
        tv24 = findViewById(R.id.textView24);
        tv25 = findViewById(R.id.textView25);
        tvr5.add(tv21);tvr5.add(tv22);tvr5.add(tv23);tvr5.add(tv24);tvr5.add(tv25);

        tv26 = findViewById(R.id.textView26);
        tv27 = findViewById(R.id.textView27);
        tv28 = findViewById(R.id.textView28);
        tv29 = findViewById(R.id.textView29);
        tv30 = findViewById(R.id.textView30);
        tvr6.add(tv26);tvr6.add(tv27);tvr6.add(tv28);tvr6.add(tv29);tvr6.add(tv30);

        tv.put(0,tvr1);tv.put(1,tvr2);tv.put(2,tvr3);tv.put(3,tvr4);tv.put(4,tvr5);tv.put(5,tvr6);

        //code to execute when button is clicked
        btn.setOnClickListener(v -> {
            //counts correctly guessed characters in particular guess
            correctCount = 0;

                //guess entered by the user
                String input = iguess.getText().toString().trim().toUpperCase(Locale.ROOT);
                word = word.toUpperCase(Locale.ROOT);

                //initialize character found count for entered guess to 0
                for(int i=0;i<5;i++){
                    found.put(input.charAt(i),0);
                }

                //Toast if invalid guess is entered
                if(input.length() == 0 || input.length()>5){
                    Toast.makeText(getApplicationContext(), "Invalid guess!", Toast.LENGTH_SHORT).show();
                }else{
                        //iterate through the input guess entered by the player
                        for(int i=0;i<5;i++){
                            TextView t;
                            t = tv.get(rowCount).get(i);
                            char c = input.charAt(i);

                            //iterating through the characters of the word
                            for(int j=i;j<5;j++){
                                char w = word.charAt(j);


                                if((c == w)) {
                                    //if the character is at the correct position
                                    if(i == j){
                                        correctCount++;
                                        Integer a = found.get(c);
                                        found.put(c,a+1);

                                        //handling repeated characters
                                        if(found.get(c)<=repeat.get(c)){
                                            t.setBackgroundColor(getResources().getColor(R.color.green));
                                        }else {
                                            t.setBackgroundColor(getResources().getColor(R.color.gray));
                                        }
                                            break;
                                    }
                                }

                                //if the character is present in the word but are at the incorrect position
                                if(word.contains(Character.toString(c))){
                                    Integer a = found.get(c);
                                    found.put(c,a+1);

                                    //handling repeated characters
                                    if(found.get(c)<=repeat.get(c)) {
                                        t.setBackgroundColor(getResources().getColor(R.color.yellow));

                                   }else{
                                        t.setBackgroundColor(getResources().getColor(R.color.gray));
                                    }

                                    break;
                                }

                                //if the character is not present in the word
                                if((c != w)) {
                                    if (j == 4) {
                                        if(found.containsKey(c)){
                                            Integer a = found.get(c);
                                            found.put(c,a+1);
                                        }
                                        t.setBackgroundColor(getResources().getColor(R.color.gray));
                                            break;
                                    }
                                }
                            }

                            /*setting text in the TextView to character entered by the user(basically displays the
                             user input in the row)
                            */

                            t.setText(String.valueOf(c));

                            //if all characters are guessed correctly and the chances are not exhausted
                            if((correctCount == 5)&&(rowCount<=6)){
                                //player wins
                                flag = 1;
                                Toast.makeText(getApplicationContext(), "YOU WON! :)", Toast.LENGTH_SHORT).show();
                                rowCount++;
                                pass_count = rowCount;
                                Intent toResult = new Intent(MainActivity.this, Result.class);
                                startActivity(toResult);
                                break;
                            }
                        }

                        rowCount++;

                        //if the player has exhausted all their chances
                        if(rowCount == 6){

                        //player loses
                        if(flag == 0){

                            Toast.makeText(getApplicationContext(), "You Lost :(", Toast.LENGTH_SHORT).show();
                            Toast.makeText(getApplicationContext(), "Correct Word: " + word, Toast.LENGTH_SHORT).show();
                            Intent youLost = new Intent(MainActivity.this, Replay.class);
                            startActivity(youLost);
                        }
                    }
                }
        });
    }

    //Overriding back button
    @Override
    public void onBackPressed(){

    }
}