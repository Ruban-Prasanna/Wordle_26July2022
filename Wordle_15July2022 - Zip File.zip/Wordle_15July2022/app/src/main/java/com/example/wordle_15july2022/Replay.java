package com.example.wordle_15july2022;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Replay extends AppCompatActivity {
    Button playAgain, gotoHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.replay);

        playAgain = findViewById(R.id.play_again_replay);
        gotoHome = findViewById(R.id.goto_home_replay);

        //resets the game and takes player to game screen
        playAgain.setOnClickListener(v1 ->  {
            Intent toMain = new Intent(Replay.this, MainActivity.class);
            startActivity(toMain);
        });

        //takes player to home activity
        gotoHome.setOnClickListener(v2 ->  {
            Intent toHome = new Intent(Replay.this, Home.class);
            startActivity(toHome);
        });

    }

    @Override
    public void onBackPressed(){

    }
}
