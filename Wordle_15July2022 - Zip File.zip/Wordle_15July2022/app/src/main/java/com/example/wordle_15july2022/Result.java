package com.example.wordle_15july2022;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Result extends AppCompatActivity {
    Button toHome, play_again;
    TextView word, chances;
    String wrd = MainActivity.word;
    Integer count = MainActivity.pass_count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);

        toHome = findViewById(R.id.goto_home);
        play_again = findViewById(R.id.play_again);
        word = findViewById(R.id.word);
        chances = findViewById(R.id.chances);

        //displays the correct word
        word.setText(wrd);

        //displays chances taken by the player
        chances.setText(String.valueOf(count));

        //resets the game and takes user to the gamescreen
        play_again.setOnClickListener(v1 ->  {
            Intent toMain = new Intent(Result.this, MainActivity.class);
            startActivity(toMain);
        });

        //takes player back to the home screen
        toHome.setOnClickListener(v2 ->  {
            Intent toHome = new Intent(Result.this, Home.class);
            startActivity(toHome);
        });
    }

    @Override
    public void onBackPressed(){

    }
}
